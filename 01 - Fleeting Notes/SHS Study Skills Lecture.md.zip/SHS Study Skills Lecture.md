---
category: general
aliases: what are the study skills necessary for unverstiy life?
audience: First Year Entrants 
topic: Study Skills
---


Gist  of the Lecture

Studying is easy
Studying is fun
Studying is very individualistic
Hybrid


Pyramid


1. Collection
2. Processing
3. Recall


Active Listening
Digital / Paperbased

Connected Thinking
[[metacognition]]


Multimedia





Link to Google Drive




tags